<div class="card">
    <div class="card-body text-center">
        <h1 class="text-danger">404</h1>
        <hr>
        <p>
            Pages not Found!
        </p>
    </div>
</div>